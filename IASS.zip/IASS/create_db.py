import sqlite3

def create_tables():
    connection = sqlite3.connect('sqlite3.db')
    cursor = connection.cursor()

    # Create Lecturer Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Lecturer (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )
    ''')

    # Create InitExam Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS InitExam (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_name TEXT NOT NULL,
        lecturer_name TEXT NOT NULL,
        exam_name TEXT NOT NULL,
        mcq_number INTEGER NOT NULL,
        mcq_points INTEGER NOT NULL,
        saq_number INTEGER NOT NULL,
        saq_points INTEGER NOT NULL,
        exam_key TEXT UNIQUE NOT NULL,
        exam_status TEXT NOT NULL,
        exam_time INTEGER NOT NULL,
        folder_path TEXT,
        questions_amount INTEGER NOT NULL,
        pass_points INTEGER NOT NULL
    )
    ''')

    # Create Questions Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        exam_name TEXT NOT NULL,
        exam_key TEXT NOT NULL,
        question TEXT NOT NULL,
        answers TEXT NOT NULL,
        correct_answer TEXT NOT NULL,
        question_type TEXT NOT NULL,
        points INTEGER NOT NULL
    )
    ''')

    # Create Submissions Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id TEXT NOT NULL,
        student_name TEXT NOT NULL,
        exam_key TEXT NOT NULL,
        exam_name TEXT NOT NULL,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        points INTEGER NOT NULL
    )
    ''')

    # Create Results Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id TEXT NOT NULL,
        student_name TEXT NOT NULL,
        exam_key TEXT NOT NULL,
        exam_name TEXT NOT NULL,
        total_marks INTEGER NOT NULL,
        show_results BOOLEAN NOT NULL,
        status TEXT NOT NULL
    )
    ''')

    # Create Students Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Students (
        student_id TEXT PRIMARY KEY,
        student_name TEXT NOT NULL,
        student_email TEXT UNIQUE NOT NULL,
        student_password TEXT NOT NULL
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS startedexams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT NOT NULL,
    exam_key TEXT NOT NULL,
    start_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, exam_key)
)
    ''')

    connection.commit()
    connection.close()

if __name__ == '__main__':
    create_tables()
    print("Database and tables created successfully.")
