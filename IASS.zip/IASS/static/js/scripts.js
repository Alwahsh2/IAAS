// Custom JavaScript can be added here
document.addEventListener("DOMContentLoaded", function() {
    // Add any JavaScript initialization here
});
