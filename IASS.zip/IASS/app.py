from datetime import datetime, timedelta
import os
import random
import hashlib
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, g, session
from werkzeug.utils import secure_filename
from tasks import process_file
from flask import jsonify
import io
import base64
import matplotlib.pyplot as plt
from flask import render_template, send_file
import matplotlib
matplotlib.use('Agg')  # Use the 'Agg' backend for rendering on a non-GUI environment

app = Flask(__name__)
app.config.update(
    CELERY_BROKER_URL='redis://localhost:6379/0',
    CELERY_RESULT_BACKEND='redis://localhost:6379/0',
    SECRET_KEY='your_secret_key',
    UPLOAD_FOLDER='uploads',
    MAX_CONTENT_LENGTH=16 * 1024 * 1024  # 16 MB limit
)

DATABASE = 'sqlite3.db'

def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# Home Page
@app.route('/')
def index():
    if session.get('user_type') == 'lecturer':
        return redirect(url_for('dashboard'))
    elif session.get('user_type') == 'student':
        return redirect(url_for('student_dashboard'))
    return render_template('index.html')

# Login Page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email'].strip()
        password = request.form['password'].strip()
        hashed_password = hash_password(password)

        db = get_db()
        cursor = db.cursor()

        # Check if the user is a lecturer
        cursor.execute('SELECT * FROM Lecturer WHERE email = ? AND password = ?', (email, hashed_password))
        lecturer = cursor.fetchone()

        if lecturer:
            session['user_id'] = lecturer[0]
            session['user_type'] = 'lecturer'
            flash("Login successful", "success")
            return redirect(url_for('dashboard'))

        # Check if the user is a student
        cursor.execute('SELECT * FROM Students WHERE student_email = ? AND student_password = ?', (email, hashed_password))
        student = cursor.fetchone()

        if student:
            session['user_id'] = student[0]
            session['user_type'] = 'student'
            session['student_id'] = student[0]  # Storing student ID for exam logic
            flash("Login successful", "success")
            return redirect(url_for('student_dashboard'))

        flash("Invalid credentials", "danger")
        return redirect(url_for('login'))  # Redirect to login page if credentials are invalid

    return render_template('login.html')


# Signup Page
@app.route('/register', methods=['GET', 'POST'])
def register():
    if session.get('user_type') == 'lecturer':
        return redirect(url_for('dashboard'))
    elif session.get('user_type') == 'student':
        return redirect(url_for('student_dashboard'))
    if request.method == 'POST':
        student_name = request.form['name']
        student_id = request.form['student_id']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            flash("Passwords do not match", "danger")
            return redirect(url_for('register'))

        db = get_db()
        cursor = db.cursor()

        cursor.execute('SELECT * FROM Students WHERE student_id = ?', (student_id,))
        existing_user = cursor.fetchone()

        if existing_user:
            flash("User with this Student ID already exists", "danger")
        else:
            hashed_password = hash_password(password)
            cursor.execute('''
                INSERT INTO Students (student_id, student_name, student_email, student_password)
                VALUES (?, ?, ?, ?)
            ''', (student_id, student_name, email, hashed_password))
            db.commit()
            flash("Registration successful", "success")
            return redirect(url_for('login'))

    return render_template('register.html')

# Lecturer Dashboard
@app.route('/dashboard')
def dashboard():
    # Fetch exams and other dashboard details
    return render_template('dashboard.html')

@app.route('/exam_distribution', methods=['GET', 'POST'])
def exam_distribution():
    db = get_db()
    cursor = db.cursor()

    # Fetch all exams for the dropdown
    cursor.execute('SELECT id, exam_name FROM InitExam')
    exams = cursor.fetchall()

    selected_exam_id = request.form.get('exam_id')
    graph_img = None

    if request.method == 'POST' and selected_exam_id:
        # Fetch the total marks for the selected exam
        cursor.execute('''
            SELECT total_marks
            FROM Results
            WHERE exam_key = (SELECT exam_key FROM InitExam WHERE id = ?)
        ''', (selected_exam_id,))
        marks = cursor.fetchall()

        if marks:
            marks = [mark[0] for mark in marks]  # Extract marks from tuples

            # Generate the normal distribution graph
            plt.figure(figsize=(10, 6))
            plt.hist(marks, bins=10, density=True, alpha=0.6, color='g')

            # Add labels and title
            plt.title('Normal Distribution of Exam Marks')
            plt.xlabel('Marks')
            plt.ylabel('Frequency')

            # Convert the plot to PNG image
            img = io.BytesIO()
            plt.savefig(img, format='png')
            img.seek(0)

            # Encode the image to base64 so it can be embedded in the HTML
            graph_img = base64.b64encode(img.getvalue()).decode()

            plt.close()

    return render_template('exam_distribution.html', exams=exams, graph_img=graph_img)
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}


@app.route('/create_exam', methods=['GET', 'POST'])
def create_exam():
    if session.get('user_type') != 'lecturer':
        flash("Access denied", "danger")
        return redirect(url_for('login'))

    if request.method == 'POST':
        subject_name = request.form['subject_name']
        lecturer_name = request.form['lecturer_name']
        exam_name = request.form['exam_name']
        mcq_number = int(request.form['mcq_number'])
        mcq_points = int(request.form['mcq_points'])
        saq_number = int(request.form['saq_number'])
        saq_points = int(request.form['saq_points'])
        exam_time = int(request.form['exam_time'])
        pass_points = int(request.form['pass_points'])
        questions_amount = int(request.form['questions_amount'])
        exam_key = hash_password(f"{exam_name}{lecturer_name}{exam_time}")
        exam_key = exam_key.strip()
        exam_key = exam_key[6:14].upper()
        print(exam_key)
        exam_status = "off"

        db = get_db()
        cursor = db.cursor()

        # Check if the exam already exists
        cursor.execute('SELECT * FROM InitExam WHERE exam_name = ? AND subject_name = ?', (exam_name, subject_name))
        existing_exam = cursor.fetchone()

        if existing_exam:
            flash("An exam with this name and subject already exists.", "danger")
            return redirect(url_for('create_exam'))

        # Create the upload folder if it doesn't exist
        exam_upload_folder = os.path.join(app.config['UPLOAD_FOLDER'], exam_name)
        if not os.path.exists(exam_upload_folder):
            os.makedirs(exam_upload_folder)

        # Save uploaded files
        files = request.files.getlist('files')
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(exam_upload_folder, filename))

        cursor.execute('''
            INSERT INTO InitExam (subject_name, lecturer_name, exam_name, mcq_number, mcq_points, saq_number, saq_points, exam_time, pass_points, questions_amount, folder_path, exam_key, exam_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            subject_name, lecturer_name, exam_name, mcq_number, mcq_points, saq_number, saq_points, exam_time,
            pass_points,
            questions_amount, exam_upload_folder, exam_key, exam_status))

        # Get the exam key (assuming it's an auto-incremented column)
        exam_id = cursor.lastrowid

        # Commit the transaction
        db.commit()

        # Call the background task twice: once for MCQ and once for SAQ
        process_file.delay(exam_upload_folder, exam_name, exam_key, 'mcq', mcq_number, mcq_points)
        process_file.delay(exam_upload_folder, exam_name, exam_key, 'saq', saq_number, saq_points)

        flash("Exam created successfully and processing started", "success")
        return redirect(url_for('dashboard'))

    return render_template('create_exam.html')

# Edit Exam Page
# Get all exams for the dropdown
@app.route('/get_exams', methods=['GET'])
def get_exams():
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT id, exam_name FROM InitExam')
    exams = cursor.fetchall()
    return exams


# Edit Exam Page
@app.route('/edit_exam', methods=['GET', 'POST'])
def edit_exam():
    if session.get('user_type') != 'lecturer':
        flash("Access denied", "danger")
        return redirect(url_for('login'))

    db = get_db()
    cursor = db.cursor()

    if request.method == 'POST':
        exam_id = request.form['exam_id']

        if 'activate_deactivate' in request.form:
            # Toggle exam status
            cursor.execute('SELECT exam_status FROM InitExam WHERE id = ?', (exam_id,))
            current_status = cursor.fetchone()[0]
            print(f"Current Status: {current_status}")  # Debug: Print current status

            new_status = 'on' if current_status == 'off' else 'off'
            cursor.execute('UPDATE InitExam SET exam_status = ? WHERE id = ?', (new_status, exam_id))
            db.commit()

            flash(f"Exam status updated to {'active' if new_status == 'on' else 'inactive'}.", "success")

        elif 'toggle_results_visibility' in request.form:
            # Toggle show_results status
            cursor.execute('SELECT show_results FROM Results WHERE exam_key = (SELECT exam_key FROM InitExam WHERE id = ?)', (exam_id,))
            current_show_results = cursor.fetchone()[0]

            new_show_results = 'on' if current_show_results == 'off' else 'off'
            cursor.execute('UPDATE Results SET show_results = ? WHERE exam_key = (SELECT exam_key FROM InitExam WHERE id = ?)', (new_show_results, exam_id))
            db.commit()

            flash(f"Results visibility updated to {'shown' if new_show_results == 'on' else 'hidden'}.", "success")

        return redirect(url_for('edit_exam', exam_id=exam_id))

    # Fetch all exams for the dropdown
    cursor.execute('SELECT id, exam_name FROM InitExam')
    exams = cursor.fetchall()

    exam = None
    questions = []
    results_visibility = None
    if 'exam_id' in request.args:
        exam_id = request.args.get('exam_id')
        cursor.execute('SELECT * FROM InitExam WHERE id = ?', (exam_id,))
        exam = cursor.fetchone()

        print(exam)  # Debug: Print the exam tuple to verify index

        if exam:
            cursor.execute('SELECT * FROM Questions WHERE exam_key = ?', (exam[8],))  # Assuming exam_key is at index 8
            questions = cursor.fetchall()

            # Check the current results visibility status
            cursor.execute('SELECT show_results FROM Results WHERE exam_key = ?', (exam[8],))
            results_visibility = cursor.fetchone()
            if results_visibility:
                results_visibility = results_visibility[0]

    return render_template('edit_exam.html', exams=exams, exam=exam, questions=questions, results_visibility=results_visibility)







@app.route('/save_question', methods=['POST'])
def save_question():
    if session.get('user_type') != 'lecturer':
        flash("Access denied", "danger")
        return redirect(url_for('login'))

    question_id = request.form['question_id']
    question = request.form['question']
    question_type = request.form['question_type']
    points = request.form['points']

    # Handle options (answers) input separately
    answers_list = request.form.getlist('answers')
    answers = '\\n'.join(answers_list)  # Joining with \n

    correct_answer = request.form['correct_answer']

    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        UPDATE Questions 
        SET question = ?, answers = ?, correct_answer = ?, question_type = ?, points = ?
        WHERE id = ? 
    ''', (question, answers, correct_answer, question_type, points, question_id))

    db.commit()
    flash("Question updated successfully", "success")
    return redirect(url_for('edit_exam', exam_id=request.form['exam_id']))


@app.route('/submissions', methods=['GET', 'POST'])
def submissions():
    db = get_db()
    cursor = db.cursor()

    # Fetch all exams for the dropdown list
    cursor.execute('SELECT id, exam_name FROM InitExam')
    exams = cursor.fetchall()

    selected_exam = None
    selected_student = None
    students = []
    submissions_data = []

    if request.method == 'POST':
        selected_exam_id = request.form.get('exam_id')
        selected_student_id = request.form.get('student_id')

        if selected_exam_id:
            # Fetch the selected exam details
            cursor.execute('SELECT exam_name FROM InitExam WHERE id = ?', (selected_exam_id,))
            selected_exam = cursor.fetchone()

            # Fetch students who have submissions for the selected exam
            cursor.execute('''
                SELECT DISTINCT student_id, student_name
                FROM Submissions
                WHERE exam_key = (SELECT exam_key FROM InitExam WHERE id = ?)
            ''', (selected_exam_id,))
            students = cursor.fetchall()

            if selected_student_id:
                # Fetch the selected student's submissions
                cursor.execute('''
                    SELECT student_id, student_name, question, answer, points
                    FROM Submissions
                    WHERE exam_key = (SELECT exam_key FROM InitExam WHERE id = ?)
                    AND student_id = ?
                ''', (selected_exam_id, selected_student_id))
                submissions_data = cursor.fetchall()

                # Debugging information
                print(f"Selected Exam ID: {selected_exam_id}, Selected Student ID: {selected_student_id}")
                print(f"Submissions Fetched: {submissions_data}")

                # Fetch the selected student's details
                cursor.execute('''
                    SELECT student_id, student_name
                    FROM Submissions
                    WHERE student_id = ?
                ''', (selected_student_id,))
                selected_student = cursor.fetchone()

    return render_template('submissions.html', exams=exams, selected_exam=selected_exam,
                           students=students, selected_student=selected_student,
                           submissions=submissions_data)



@app.route('/approve_submission', methods=['POST'])
def approve_submission():
    student_id = request.form.get('student_id')
    exam_key = request.form.get('exam_key')
    question = request.form.get('question')
    points = int(request.form.get('points'))

    db = get_db()
    cursor = db.cursor()

    # Fetch the current total marks for the student
    cursor.execute('SELECT total_marks FROM Results WHERE student_id = ? AND exam_name = ?', (student_id, exam_key))
    result = cursor.fetchone()

    cursor.execute('SELECT pass_points FROM InitExam WHERE exam_name = ?', (exam_key,))
    pass_points = cursor.fetchone()[0]

    if result:
        current_total_marks = result[0]
        new_total_marks = current_total_marks + points

        # Determine the new status based on the updated total marks
        status = "pass" if new_total_marks >= pass_points else "fail"

        # Update the total marks and status in the Results table
        cursor.execute('''
                UPDATE Results
                SET total_marks = ?, status = ?
                WHERE student_id = ? AND exam_name = ?
            ''', (new_total_marks, status, student_id, exam_key))

    # Delete the submission from the Submissions table
    cursor.execute('''
            DELETE FROM Submissions
            WHERE student_id = ? AND exam_name = ? AND question = ?
        ''', (student_id, exam_key, question))

    db.commit()

    return jsonify({"status": "success", "message": "Submission approved and updated."})


# View/Edit Results Page
@app.route('/results/<int:exam_id>')
def results(exam_id):
    # Fetch results for the exam
    return render_template('results.html', exam_id=exam_id)

# Student Dashboard
@app.route('/student_dashboard')
def student_dashboard():
    # Check for a message in the query parameters
    message = request.args.get('message')
    if message:
        flash(message, "warning")

    return render_template('student_dashboard.html')

# Take Exam Page
@app.route('/take_exam', methods=['GET', 'POST'])
def take_exam():
    if request.method == 'POST':
        exam_key = request.form.get('exam_key').strip().upper()

        # Query to find the exam by exam_key
        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT exam_name, exam_status FROM InitExam WHERE exam_key = ?', (exam_key,))
        exam = cursor.fetchone()

        if exam is None:
            flash("Invalid exam key. Please check your entry and try again.", "danger")
            return redirect(url_for('take_exam'))

        exam_name, exam_status = exam

        if exam_status != 'on':
            flash(f"The exam '{exam_name}' is currently inactive. Please contact your instructor.", "warning")
            return redirect(url_for('take_exam'))

        # If the exam is active, proceed to the exam page
        return redirect(url_for('start_exam', exam_key=exam_key))

    return render_template('take_exam.html')


# Start Exam Page (based on exam key)
@app.route('/start_exam/<exam_key>', methods=['GET', 'POST'])
def start_exam(exam_key):
    if 'student_id' not in session:
        flash("Please log in to take the exam.", "warning")
        return redirect(url_for('login'))

    # Open a new database connection
    db = get_db()
    cursor = db.cursor()

    if request.method == 'GET':
        # Check if the user has already started the exam
        cursor.execute('SELECT * FROM startedexams WHERE student_id = ? AND exam_key = ?',
                       (session['student_id'], exam_key))
        started_exam = cursor.fetchone()

        if started_exam:
            flash("You have already started this exam.", "warning")
            return redirect(url_for('take_exam'))

        # Fetch exam details
        cursor.execute('SELECT * FROM InitExam WHERE exam_key = ?', (exam_key,))
        exam = cursor.fetchone()

        if exam is None:
            flash("Exam not found.", "danger")
            return redirect(url_for('take_exam'))

        if exam[9] != 'on':
            flash("The exam is not active.", "danger")
            return redirect(url_for('take_exam'))

        # Insert into startedexams table to mark the exam as started
        cursor.execute('''
            INSERT INTO startedexams (student_id, exam_key)
            VALUES (?, ?)
        ''', (session['student_id'], exam_key))
        db.commit()

        # Get the exam time, mcq_number, and saq_number
        exam_time_minutes = int(exam[10])
        mcq_number = int(exam[4])  # Assuming mcq_number is at index 4
        saq_number = int(exam[6])  # Assuming saq_number is at index 6
        pass_points = int(exam[13])  # Assuming pass_points is at index 13

        # Fetch all questions for the exam
        cursor.execute('SELECT * FROM Questions WHERE exam_key = ?', (exam_key,))
        all_questions = cursor.fetchall()

        # Separate SAQ and MCQ questions
        saq_questions = [q for q in all_questions if q[6] == 'saq']
        mcq_questions = [q for q in all_questions if q[6] == 'mcq']

        # Randomly select the required number of SAQ and MCQ questions
        selected_saq_questions = random.sample(saq_questions, saq_number) if saq_number <= len(saq_questions) else saq_questions
        selected_mcq_questions = random.sample(mcq_questions, mcq_number) if mcq_number <= len(mcq_questions) else mcq_questions

        # Combine the selected questions and shuffle them
        selected_questions = selected_saq_questions + selected_mcq_questions
        random.shuffle(selected_questions)

        # Calculate the total number of selected questions
        total_questions = len(selected_questions)

        # Store variables in the session
        session['exam'] = exam
        session['pass_points'] = pass_points
        session['selected_questions'] = selected_questions

        # Calculate the exam end time for the timer in UTC to ensure consistency across devices
        end_time = (datetime.utcnow() + timedelta(minutes=exam_time_minutes)).strftime('%Y-%m-%d %H:%M:%S')

        return render_template('start_exam.html', exam=exam, questions=selected_questions, end_time=end_time,
                               exam_time_minutes=exam_time_minutes, total_questions=total_questions)

    elif request.method == 'POST':

        # Retrieve variables from the session
        exam = session.get('exam')
        pass_points = session.get('pass_points')
        selected_questions = session.get('selected_questions')

        # Get student_name from the session or fetch from the database if not available
        student_name = session.get('student_name')

        if not student_name:
            # Fetch student_name from the database
            cursor.execute('SELECT student_name FROM Students WHERE student_id = ?', (session['student_id'],))
            student_record = cursor.fetchone()

            if student_record:
                student_name = student_record[0]
                session['student_name'] = student_name  # Store in session for future use
            else:
                flash("Student name not found.", "danger")
                return redirect(url_for('take_exam'))

        score = 0
        total_points = 0

        # Prepare SAQ answers to insert into the Submissions table
        saq_submissions = []

        for question in selected_questions:
            question_id = question[0]
            question_text = question[3]
            question_type = question[6]
            points = question[7]
            total_points += points

            if question_type == 'mcq':
                user_answer = request.form.get(f'question_{question_id}')
                if user_answer == question[5]:  # correct_answer is at index 5
                    score += points

            elif question_type == 'saq':
                user_answer = request.form.get(f'question_{question_id}')
                saq_submissions.append(
                    (session['student_id'], student_name, exam_key, exam[3], question_text, user_answer, points))

        # Insert SAQ answers with points into the Submissions table
        cursor.executemany('''
            INSERT INTO Submissions (student_id, student_name, exam_key, exam_name, question, answer, points)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', saq_submissions)

        # Determine the status (pass/fail)
        status = "pass" if score >= pass_points else "fail"
        print("MCQ Score:", score, "Status:", status)

        try:
            # Insert total score, status, and show_results into the Results table
            cursor.execute('''
                INSERT INTO Results (student_id, student_name, exam_key, exam_name, total_marks, show_results, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (session['student_id'], student_name, exam_key, exam[3], score, 'off', status))
            db.commit()
            print("Inserted into Results:", session['student_id'], student_name, exam_key, exam[3], score, 'off', status)
        except Exception as e:
            print(f"Failed to insert into Results table: {e}")

        # Clear session variables after the exam is processed
        session.pop('exam', None)
        session.pop('pass_points', None)
        session.pop('selected_questions', None)

        flash("Exam submitted successfully.", "success")
        return redirect(url_for('student_dashboard'))

    # Close the database connection at the end of the request
    db.close()


@app.route('/view_submissions', methods=['GET', 'POST'])
def view_submissions():
    if session.get('user_type') != 'lecturer':
        flash("Access denied", "danger")
        return redirect(url_for('login'))

    db = get_db()
    cursor = db.cursor()

    if request.method == 'GET':
        # Fetch all exams for the dropdown list
        cursor.execute('SELECT exam_key, exam_name FROM InitExam')
        exams = cursor.fetchall()
        return render_template('view_submissions.html', exams=exams)

    elif request.method == 'POST':
        # Get the selected exam_key from the form
        exam_key = request.form.get('exam_key')

        # Fetch the submissions for the selected exam
        cursor.execute('''
            SELECT student_id, student_name, question, answer, points 
            FROM Submissions 
            WHERE exam_key = ?
        ''', (exam_key,))
        submissions = cursor.fetchall()

        # Fetch the exam names for the dropdown list again
        cursor.execute('SELECT exam_key, exam_name FROM InitExam')
        exams = cursor.fetchall()

        return render_template('view_submissions.html', exams=exams, submissions=submissions, selected_exam_key=exam_key)

# View Results Page
@app.route('/view_results', methods=['GET', 'POST'])
def view_results():
    db = get_db()
    cursor = db.cursor()

    results = []
    exams = []

    if session.get('user_type') == 'lecturer':
        # Fetch all exams for the dropdown list
        cursor.execute('SELECT id, exam_name FROM InitExam')
        exams = cursor.fetchall()

        selected_exam_id = request.form.get('exam_id')

        if request.method == 'POST' and selected_exam_id:
            cursor.execute('''
                SELECT R.student_id, R.student_name, R.exam_name, R.total_marks, R.status
                FROM Results R
                JOIN InitExam E ON R.exam_key = E.exam_key
                WHERE E.id = ?
            ''', (selected_exam_id,))
            results = cursor.fetchall()

    elif session.get('user_type') == 'student':
        # Fetch results for the logged-in student, only if show_results is 'on'
        cursor.execute('''
            SELECT exam_name, total_marks, status
            FROM Results
            WHERE student_id = ? AND show_results = 'on'
        ''', (session['user_id'],))
        results = cursor.fetchall()

    return render_template('view_results.html', results=results, exams=exams)





# Delete Question
@app.route('/delete_question/<int:question_id>', methods=['POST'])
def delete_question(question_id):
    if session.get('user_type') != 'lecturer':
        flash("Access denied", "danger")
        return redirect(url_for('login'))

    db = get_db()
    cursor = db.cursor()
    cursor.execute('DELETE FROM Questions WHERE id = ?', (question_id,))
    db.commit()
    flash("Question deleted successfully", "success")
    return redirect(request.referrer)  # Redirect back to the page that sent the request

# List Exams Page
@app.route('/list_exams')
def list_exams():
    if session.get('user_type') != 'lecturer':
        flash("Access denied", "danger")
        return redirect(url_for('login'))

    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT exam_name, exam_key, exam_time, exam_status FROM InitExam')
    exams = cursor.fetchall()

    return render_template('list_exams.html', exams=exams)

# Logout Route
@app.route('/logout')
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5011)