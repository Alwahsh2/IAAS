import sqlite3
import hashlib

DATABASE = 'sqlite3.db'

def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()

def insert_lecturer(name, email, password):
    hashed_password = hash_password(password)

    connection = sqlite3.connect(DATABASE)
    cursor = connection.cursor()

    cursor.execute('''
        INSERT INTO Lecturer (name, email, password)
        VALUES (?, ?, ?)
    ''', (name, email, hashed_password))

    connection.commit()
    connection.close()

if __name__ == '__main__':
    name = input("Enter Lecturer Name: ")
    email = input("Enter Lecturer Email: ")
    password = input("Enter Lecturer Password: ")

    insert_lecturer(name, email, password)
    print("Lecturer account created successfully.")
