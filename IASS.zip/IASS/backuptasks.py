from celery_config import celery
from openai import OpenAI
import json
import os
import PyPDF2
from pptx import Presentation
import sqlite3

client = OpenAI(api_key='sk-proj-XBN1mWrWCP_MwVpxs1XeR7cUfRSVCgdE-qZiGTZnRBz-')


# Function to read content from a PDF file using PyPDF2
def read_pdf_content(file_path):
    text = ""
    with open(file_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        for page_num in range(len(reader.pages)):
            page = reader.pages[page_num]
            text += page.extract_text()
    return text


# Function to read content from a PPTX file using python-pptx
def read_pptx_content(file_path):
    prs = Presentation(file_path)
    text = ""
    for slide in prs.slides:
        for shape in slide.shapes:
            if hasattr(shape, "text"):
                text += shape.text + "\n"
    return text


# Function to read content from a markdown file
def read_md_content(file_path):
    with open(file_path, "r") as file:
        text = file.read()
    return text


# Function to split the text into chunks
def split_text_into_chunks(text, max_tokens):
    words = text.split()
    chunks = []
    current_chunk = []
    current_length = 0

    for word in words:
        word_length = len(word) + 1  # +1 for the space
        if current_length + word_length > max_tokens:
            chunks.append(' '.join(current_chunk))
            current_chunk = [word]
            current_length = word_length
        else:
            current_chunk.append(word)
            current_length += word_length

    if current_chunk:
        chunks.append(' '.join(current_chunk))

    return chunks


# Function to interact with ChatGPT using the file content
def interact_with_chatgpt(file_content, instruction, exam_name, exam_key, question_type, points):
    chunks = split_text_into_chunks(file_content, max_tokens=2048)
    responses = []

    for i, chunk in enumerate(chunks):
        prompt = f"{instruction}\n\nFile content (Part {i + 1}/{len(chunks)}):\n{chunk}"
        print(prompt)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system",
                 "content": "You will receive content of files, see my request to tell you what to do with it."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=500
        )
        responses.append(response.choices[0].message.content.strip())
        data = f"{response.choices[0].message.content}"
        if "```json" in data:
            data = data.replace("```json", "")
        if "```" in data:
            data = data.replace("```", "")
        quiz_data = json.loads(data)
        for question_data in quiz_data["questions"]:
            question = question_data["question"]
            if question_type.lower() == "mcq":
                options = json.dumps(question_data["options"])
                answer = question_data["answer"]
            else:
                options = "None"
                answer = "None"

            # Save question to the database
            save_question_to_db(exam_name, exam_key, question, options, answer, question_type, points)

            print(f"Question: {question}")
            if options:
                for option, option_text in json.loads(options).items():
                    print(f"{option}: {option_text}")
            print(f"Answer: {answer}\n")
    return " ".join(responses)


def save_question_to_db(exam_name, exam_key, question, options, answer, question_type, points):
    conn = sqlite3.connect('sqlite3.db')
    cur = conn.cursor()
    cur.execute('''
        INSERT INTO Questions (exam_name, exam_key, question, answers, correct_answer, question_type, points)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (exam_name, exam_key, question, options, answer, question_type, points))
    conn.commit()
    conn.close()


@celery.task(name='tasks.process_file')
def process_file(folder_path, exam_name, exam_key, question_type, number, points):
    for file_name in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file_name)
        if file_path.endswith('.md'):
            file_content = read_md_content(file_path)
        elif file_path.endswith('.pdf'):
            file_content = read_pdf_content(file_path)
        elif file_path.endswith('.pptx') or file_path.endswith('.ppt'):
            file_content = read_pptx_content(file_path)
        else:
            raise ValueError("Unsupported file type")

        instruction = ""
        if question_type.lower() == "mcq":
            instruction = (
                f"Create me {number} MCQ json array 'questions' for each part of the file, And give me the correct choice for each question with "
                "its number. And make the response in json. In the json each question is in 'question' key and its options "
                "is under 'options' key and it's all in one value and sperated by \\n, then the answer is under 'answer' key "
                f", Also points key which has {points} for each question, Finally don't "
                "response with anything except the json data")
        elif question_type.lower() == "saq":
            instruction = (
                f"Create me {number} SAQ array json 'questions' for each part of the file, And make the response in json. In the json each question is in 'question', Also points key which has {points} for each question, Finally don't "
                "response with anything except the json data")

        result = interact_with_chatgpt(file_content, instruction, exam_name, exam_key, question_type, points)
        return result
